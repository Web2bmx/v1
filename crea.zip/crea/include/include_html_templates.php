<!--control-color-->
<div class="control-color template">
	<h4></h4>
	<div class="control-color-thumb">
		<div class="control-color-thumb-bg"><div class="control-color-thumb-content"></div></div>
		<div class="control-color-thumb-bg"><div class="control-color-thumb-content"></div></div>
		<div class="control-color-thumb-bg"><div class="control-color-thumb-content"></div></div>
	</div>		
	<input type="radio" name="inp-palette" value="" style="display: none;" />
</div>
<!--img-thumb-->
<div class="img-thumb template">
	<div class='img-thumb-cont'></div>
	<input type="radio" name="" value="" style="display: none;" />		
</div> 